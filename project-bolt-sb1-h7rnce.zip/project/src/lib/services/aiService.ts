import OpenAI from 'openai';

export class AIService {
  private openai: OpenAI;

  constructor() {
    this.openai = new OpenAI({
      apiKey: process.env.VITE_OPENAI_API_KEY
    });
  }

  async getResponse(transcription: string) {
    const completion = await this.openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content: "Vous êtes une secrétaire professionnelle. Répondez de manière naturelle et efficace."
        },
        {
          role: "user",
          content: transcription
        }
      ]
    });

    return completion.choices[0].message.content;
  }
}