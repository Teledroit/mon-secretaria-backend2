import { Device } from '@twilio/voice-sdk';
import { generateResponse } from '../openai';
import { SpeechClient } from '@google-cloud/speech';
import { TextToSpeechClient } from '@google-cloud/text-to-speech';

export class TwilioService {
  private device: Device;
  private speechClient: SpeechClient;
  private ttsClient: TextToSpeechClient;

  constructor() {
    this.speechClient = new SpeechClient();
    this.ttsClient = new TextToSpeechClient();
  }

  async setupDevice(token: string) {
    this.device = new Device(token, {
      codecPreferences: ['opus', 'pcmu'],
      fakeLocalDTMF: true,
      enableRingingState: true
    });

    await this.device.register();
    this.setupListeners();
  }

  private setupListeners() {
    this.device.on('incoming', (connection) => {
      this.handleIncomingCall(connection);
    });

    this.device.on('error', (error) => {
      console.error('Twilio Device error:', error);
    });
  }

  private async handleIncomingCall(connection: any) {
    // Configuration de la reconnaissance vocale
    const request = {
      config: {
        encoding: 'LINEAR16',
        sampleRateHertz: 16000,
        languageCode: 'fr-FR',
      },
      interimResults: true,
    };

    // Créer un stream de reconnaissance vocale
    const recognizeStream = this.speechClient
      .streamingRecognize(request)
      .on('data', async (data) => {
        const transcription = data.results[0].alternatives[0].transcript;
        
        // Obtenir la réponse de l'IA
        const aiResponse = await generateResponse(transcription);

        // Convertir la réponse en audio
        const [ttsResponse] = await this.ttsClient.synthesizeSpeech({
          input: { text: aiResponse },
          voice: { languageCode: 'fr-FR', ssmlGender: 'FEMALE' },
          audioConfig: { audioEncoding: 'MP3' },
        });

        // Jouer la réponse audio
        if (connection && ttsResponse.audioContent) {
          connection.play(Buffer.from(ttsResponse.audioContent));
        }
      })
      .on('error', (error) => {
        console.error('Speech recognition error:', error);
      });

    // Connecter le flux audio de l'appel à la reconnaissance vocale
    if (connection.stream) {
      connection.stream.pipe(recognizeStream);
    }
  }

  disconnect() {
    if (this.device) {
      this.device.destroy();
    }
  }
}