import { TextToSpeechClient } from '@google-cloud/text-to-speech';

export class TTSService {
  private client: TextToSpeechClient;

  constructor() {
    this.client = new TextToSpeechClient();
  }

  async synthesizeSpeech(text: string) {
    const request = {
      input: { text },
      voice: {
        languageCode: 'fr-FR',
        name: 'fr-FR-Standard-A',
        ssmlGender: 'FEMALE'
      },
      audioConfig: { audioEncoding: 'MP3' }
    };

    const [response] = await this.client.synthesizeSpeech(request);
    return response.audioContent;
  }
}