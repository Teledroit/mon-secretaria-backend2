export class CallHandler {
  constructor(
    private twilioService: TwilioService,
    private speechService: SpeechService,
    private aiService: AIService,
    private ttsService: TTSService
  ) {}

  async handleCall(call: any) {
    // 1. Démarrer la transcription
    const transcriptionStream = await this.speechService.transcribeAudio(call.stream);

    // 2. Écouter les transcriptions
    transcriptionStream.on('transcription', async (text) => {
      // 3. Obtenir la réponse de l'IA
      const aiResponse = await this.aiService.getResponse(text);

      // 4. Convertir la réponse en audio
      const audioResponse = await this.ttsService.synthesizeSpeech(aiResponse);

      // 5. Jouer la réponse dans l'appel
      call.play(audioResponse);
    });
  }
}