import { SpeechClient } from '@google-cloud/speech';

export class SpeechService {
  private client: SpeechClient;

  constructor() {
    this.client = new SpeechClient();
  }

  async transcribeAudio(audioStream: any) {
    const config = {
      encoding: 'LINEAR16',
      sampleRateHertz: 16000,
      languageCode: 'fr-FR',
    };

    const request = {
      config,
      interimResults: true,
    };

    const recognizeStream = this.client
      .streamingRecognize(request)
      .on('data', (data) => {
        const transcription = data.results[0].alternatives[0].transcript;
        // Émettre la transcription en temps réel
        this.emit('transcription', transcription);
      });

    audioStream.pipe(recognizeStream);
  }
}