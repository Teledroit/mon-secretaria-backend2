import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true
});

export async function generateResponse(transcript: string): Promise<string> {
  try {
    const completion = await openai.chat.completions.create({
      messages: [
        {
          role: "system",
          content: "Vous êtes un assistant virtuel professionnel pour un cabinet d'avocats. Répondez de manière concise et professionnelle."
        },
        {
          role: "user",
          content: transcript
        }
      ],
      model: "gpt-4-turbo-preview",
    });

    return completion.choices[0].message.content;
  } catch (error) {
    console.error('Error generating AI response:', error);
    return "Désolé, je n'ai pas pu générer une réponse. Veuillez réessayer.";
  }
}