const SCOPES = ['https://www.googleapis.com/auth/calendar'];
const CLIENT_ID = '519061813383-nsgfhn0aooj2b61ps68lcoluuelqkfp0.apps.googleusercontent.com';
const REDIRECT_URI = 'https://monsecretaria.com/calendar/callback';

export function getAuthUrl(): string {
  const params = new URLSearchParams({
    client_id: CLIENT_ID,
    redirect_uri: REDIRECT_URI,
    response_type: 'code',
    access_type: 'offline',
    scope: SCOPES.join(' ')
  });
  
  return `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
}

export async function handleAuthCallback(code: string): Promise<any> {
  const response = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      code,
      client_id: CLIENT_ID,
      redirect_uri: REDIRECT_URI,
      grant_type: 'authorization_code'
    })
  });

  if (!response.ok) {
    throw new Error('Failed to get access token');
  }

  const tokens = await response.json();
  setStoredCredentials(tokens);
  return tokens;
}

export function setStoredCredentials(credentials: any): void {
  localStorage.setItem('calendar_credentials', JSON.stringify(credentials));
}

export function getStoredCredentials(): any {
  const stored = localStorage.getItem('calendar_credentials');
  return stored ? JSON.parse(stored) : null;
}

export function clearStoredCredentials(): void {
  localStorage.removeItem('calendar_credentials');
}