import { getStoredCredentials } from './auth';

const CALENDAR_API_BASE = 'https://www.googleapis.com/calendar/v3';

async function fetchWithAuth(endpoint: string, options: RequestInit = {}) {
  const credentials = getStoredCredentials();
  if (!credentials?.access_token) {
    throw new Error('No access token available');
  }

  const response = await fetch(`${CALENDAR_API_BASE}${endpoint}`, {
    ...options,
    headers: {
      ...options.headers,
      'Authorization': `Bearer ${credentials.access_token}`,
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    throw new Error(`Calendar API error: ${response.statusText}`);
  }

  return response.json();
}

export async function listEvents(timeMin: Date, timeMax: Date) {
  const params = new URLSearchParams({
    timeMin: timeMin.toISOString(),
    timeMax: timeMax.toISOString(),
    singleEvents: 'true',
    orderBy: 'startTime'
  });

  return fetchWithAuth(`/calendars/primary/events?${params}`);
}

export async function createEvent(event: {
  summary: string;
  description?: string;
  start: Date;
  end: Date;
}) {
  return fetchWithAuth('/calendars/primary/events', {
    method: 'POST',
    body: JSON.stringify({
      summary: event.summary,
      description: event.description,
      start: { dateTime: event.start.toISOString() },
      end: { dateTime: event.end.toISOString() }
    })
  });
}