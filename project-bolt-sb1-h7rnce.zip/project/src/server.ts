import express from 'express';
import dotenv from 'dotenv';
import voiceRoutes from './api/voice';
import twilio from 'twilio';

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

// Vérification des variables d'environnement requises
const requiredEnvVars = [
  'TWILIO_ACCOUNT_SID',
  'TWILIO_AUTH_TOKEN',
  'TWILIO_PHONE_NUMBER'
];

requiredEnvVars.forEach(varName => {
  if (!process.env[varName]) {
    console.error(`Error: ${varName} is not set in environment variables`);
    process.exit(1);
  }
});

// Configuration de Twilio
const twilioClient = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

// Middleware pour parser les requêtes
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Middleware pour vérifier les requêtes Twilio
app.use('/api/voice', twilio.webhook({ validate: true }));

// Routes Twilio
app.use('/api', voiceRoutes);

// Route de test pour vérifier que le serveur fonctionne
app.get('/health', (req, res) => {
  res.json({ status: 'ok', twilioNumber: process.env.TWILIO_PHONE_NUMBER });
});

// Gestion des erreurs
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('Server error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
  console.log(`Twilio number configured: ${process.env.TWILIO_PHONE_NUMBER}`);
});