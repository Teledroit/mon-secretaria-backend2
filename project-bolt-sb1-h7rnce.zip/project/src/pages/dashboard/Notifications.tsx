import { useState } from 'react';
import { Bell, Calendar, PhoneForwarded, AlertCircle } from 'lucide-react';
import Button from '@/components/ui/Button';

interface NotificationSettings {
  appointments: {
    enabled: boolean;
    email: boolean;
    sms: boolean;
  };
  urgentCalls: {
    enabled: boolean;
    email: boolean;
    sms: boolean;
  };
  importantRequests: {
    enabled: boolean;
    email: boolean;
    threshold: string;
  };
}

export default function Notifications() {
  const [settings, setSettings] = useState<NotificationSettings>({
    appointments: {
      enabled: true,
      email: true,
      sms: false,
    },
    urgentCalls: {
      enabled: true,
      email: true,
      sms: true,
    },
    importantRequests: {
      enabled: true,
      email: true,
      threshold: 'high',
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Notification settings saved:', settings);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Me notifier quand</h1>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Rendez-vous */}
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center gap-2 mb-6">
            <Calendar className="w-5 h-5 text-blue-600" />
            <h2 className="text-lg font-medium">Prise de rendez-vous</h2>
          </div>

          <div className="space-y-4">
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                checked={settings.appointments.enabled}
                onChange={(e) => setSettings({
                  ...settings,
                  appointments: { ...settings.appointments, enabled: e.target.checked }
                })}
                className="rounded text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm font-medium text-gray-700">
                Activer les notifications de rendez-vous
              </span>
            </label>

            <div className="pl-6 space-y-3">
              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={settings.appointments.email}
                  onChange={(e) => setSettings({
                    ...settings,
                    appointments: { ...settings.appointments, email: e.target.checked }
                  })}
                  disabled={!settings.appointments.enabled}
                  className="rounded text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm text-gray-700">Notification par email</span>
              </label>

              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={settings.appointments.sms}
                  onChange={(e) => setSettings({
                    ...settings,
                    appointments: { ...settings.appointments, sms: e.target.checked }
                  })}
                  disabled={!settings.appointments.enabled}
                  className="rounded text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm text-gray-700">Notification par SMS</span>
              </label>
            </div>
          </div>
        </div>

        {/* Appels urgents */}
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center gap-2 mb-6">
            <PhoneForwarded className="w-5 h-5 text-blue-600" />
            <h2 className="text-lg font-medium">Transfert d'appel urgent</h2>
          </div>

          <div className="space-y-4">
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                checked={settings.urgentCalls.enabled}
                onChange={(e) => setSettings({
                  ...settings,
                  urgentCalls: { ...settings.urgentCalls, enabled: e.target.checked }
                })}
                className="rounded text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm font-medium text-gray-700">
                Activer les notifications d'appels urgents
              </span>
            </label>

            <div className="pl-6 space-y-3">
              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={settings.urgentCalls.email}
                  onChange={(e) => setSettings({
                    ...settings,
                    urgentCalls: { ...settings.urgentCalls, email: e.target.checked }
                  })}
                  disabled={!settings.urgentCalls.enabled}
                  className="rounded text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm text-gray-700">Notification par email</span>
              </label>

              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={settings.urgentCalls.sms}
                  onChange={(e) => setSettings({
                    ...settings,
                    urgentCalls: { ...settings.urgentCalls, sms: e.target.checked }
                  })}
                  disabled={!settings.urgentCalls.enabled}
                  className="rounded text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm text-gray-700">Notification par SMS</span>
              </label>
            </div>
          </div>
        </div>

        {/* Demandes importantes */}
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center gap-2 mb-6">
            <AlertCircle className="w-5 h-5 text-blue-600" />
            <h2 className="text-lg font-medium">Demandes importantes</h2>
          </div>

          <div className="space-y-4">
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                checked={settings.importantRequests.enabled}
                onChange={(e) => setSettings({
                  ...settings,
                  importantRequests: { ...settings.importantRequests, enabled: e.target.checked }
                })}
                className="rounded text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm font-medium text-gray-700">
                Activer les notifications de demandes importantes
              </span>
            </label>

            <div className="pl-6 space-y-3">
              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={settings.importantRequests.email}
                  onChange={(e) => setSettings({
                    ...settings,
                    importantRequests: { ...settings.importantRequests, email: e.target.checked }
                  })}
                  disabled={!settings.importantRequests.enabled}
                  className="rounded text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm text-gray-700">Notification par email</span>
              </label>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Seuil d'importance
                </label>
                <select
                  value={settings.importantRequests.threshold}
                  onChange={(e) => setSettings({
                    ...settings,
                    importantRequests: { ...settings.importantRequests, threshold: e.target.value }
                  })}
                  disabled={!settings.importantRequests.enabled}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                >
                  <option value="low">Faible</option>
                  <option value="medium">Moyen</option>
                  <option value="high">Élevé</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        <Button type="submit" className="w-full">
          <Bell className="w-4 h-4 mr-2" />
          Enregistrer les préférences de notification
        </Button>
      </form>
    </div>
  );
}