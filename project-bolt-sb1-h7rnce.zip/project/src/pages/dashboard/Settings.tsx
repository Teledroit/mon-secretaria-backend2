import { useState } from 'react';
import AIConfiguration from '@/components/settings/AIConfiguration';
import DocumentsConfig from '@/components/settings/DocumentsConfig';
import WorkflowConfig from '@/components/settings/WorkflowConfig';
import PrivacySettings from '@/components/settings/PrivacySettings';
import GeneralSettings from '@/components/settings/GeneralSettings';

export default function Settings() {
  const [settings, setSettings] = useState({
    welcomeMessage: "Bonjour, vous êtes en communication avec l'assistant virtuel du cabinet. Comment puis-je vous aider ?",
    voiceType: "female",
    latency: 0.5,
    interruptionSensitivity: 0.7,
    enableBackchanneling: true,
    maxCallDuration: 20,
    silenceTimeout: 5,
    detectVoicemail: true,
    enableSpeechNormalization: true,
    workingHours: {
      start: "09:00",
      end: "18:00"
    },
    notifications: {
      email: true,
      sms: false
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Settings saved:', settings);
  };

  const handleAIConfigSave = (aiConfig: any) => {
    console.log('AI Configuration saved:', aiConfig);
  };

  const handlePrivacySettingsSave = (privacySettings: any) => {
    console.log('Privacy settings saved:', privacySettings);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Configuration</h1>
      </div>

      <div className="grid grid-cols-1 gap-6">
        <AIConfiguration onSave={handleAIConfigSave} />
        <DocumentsConfig />
        <WorkflowConfig />
        <PrivacySettings onSave={handlePrivacySettingsSave} />
        <GeneralSettings 
          settings={settings}
          onSettingsChange={setSettings}
          onSubmit={handleSubmit}
        />
      </div>
    </div>
  );
}