import { useState } from 'react';
import BillingHeader from '@/components/billing/BillingHeader';
import UsageSummary from '@/components/billing/UsageSummary';
import InvoiceList from '@/components/billing/InvoiceList';
import PaymentMethods from '@/components/billing/PaymentMethods';
import BillingInfo from '@/components/billing/BillingInfo';

// Données de démonstration
const demoData = {
  currentPlan: 'Pro',
  isOverdue: false,
  currentUsage: {
    minutes: 750,
    cost: 112.50,
    averageCost: 0.15
  },
  limits: {
    minutes: 1000,
    remaining: 250
  },
  invoices: [
    { id: '1', date: '01/03/2024', amount: 112.50, status: 'pending' as const, downloadUrl: '#' },
    { id: '2', date: '01/02/2024', amount: 99.00, status: 'paid' as const, downloadUrl: '#' },
    { id: '3', date: '01/01/2024', amount: 99.00, status: 'paid' as const, downloadUrl: '#' }
  ],
  paymentMethods: [
    { id: '1', type: 'card' as const, last4: '4242', expiryDate: '12/25', isDefault: true },
    { id: '2', type: 'sepa' as const, last4: '1234', isDefault: false }
  ],
  billingInfo: {
    companyName: 'Cabinet Dupont & Associés',
    address: '123 Avenue des Champs-Élysées',
    city: 'Paris',
    postalCode: '75008',
    country: 'France',
    vatNumber: 'FR12345678900',
    email: 'facturation@cabinet-dupont.fr'
  }
};

export default function Billing() {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const handleViewInvoice = (id: string) => {
    console.log('Viewing invoice:', id);
  };

  const handleDownloadInvoice = (id: string) => {
    console.log('Downloading invoice:', id);
  };

  const handleAddPaymentMethod = () => {
    console.log('Adding payment method');
  };

  const handleRemovePaymentMethod = (id: string) => {
    console.log('Removing payment method:', id);
  };

  const handleSetDefaultPaymentMethod = (id: string) => {
    console.log('Setting default payment method:', id);
  };

  const handleEditBillingInfo = () => {
    console.log('Editing billing info');
  };

  return (
    <div className="space-y-8">
      <BillingHeader 
        currentPlan={demoData.currentPlan}
        isOverdue={demoData.isOverdue}
      />

      <UsageSummary 
        currentUsage={demoData.currentUsage}
        limits={demoData.limits}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <PaymentMethods
          methods={demoData.paymentMethods}
          onAddMethod={handleAddPaymentMethod}
          onRemoveMethod={handleRemovePaymentMethod}
          onSetDefault={handleSetDefaultPaymentMethod}
        />

        <BillingInfo
          info={demoData.billingInfo}
          onEdit={handleEditBillingInfo}
        />
      </div>

      <InvoiceList
        invoices={demoData.invoices}
        onViewInvoice={handleViewInvoice}
        onDownloadInvoice={handleDownloadInvoice}
      />
    </div>
  );
}