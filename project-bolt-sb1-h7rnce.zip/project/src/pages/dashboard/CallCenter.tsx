import { useState } from 'react';
import { Phone, Mic, PhoneOff } from 'lucide-react';
import Button from '@/components/ui/Button';
import CallFilters from '@/components/dashboard/calls/CallFilters';
import CallList from '@/components/dashboard/calls/CallList';

// Données de démonstration
const demoData = {
  calls: [
    {
      id: '1',
      date: '2024-03-15',
      time: '14:30',
      duration: '5:23',
      type: 'Entrant',
      cost: 0.75,
      status: 'success',
      sentiment: 'positive',
      from: '+33 6 12 34 56 78',
      to: 'Assistant IA (F)',
      successful: true,
      latency: 150
    },
    {
      id: '2',
      date: '2024-03-15',
      time: '13:15',
      duration: '3:45',
      type: 'Sortant',
      cost: 0.45,
      status: 'failed',
      sentiment: 'negative',
      from: 'Assistant IA (F)',
      to: '+33 6 98 76 54 32',
      successful: false,
      latency: 180
    }
  ]
};

export default function CallCenter() {
  const [isInCall, setIsInCall] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [filters, setFilters] = useState({});
  const [sortField, setSortField] = useState('date');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [assistantGender] = useState<'F' | 'H'>('F'); // Genre par défaut

  const handleCall = () => {
    setIsInCall(true);
    setTranscription('Client : Bonjour, j\'aimerais prendre rendez-vous...');
    setAiResponse('Je peux vous aider à planifier un rendez-vous. Quel type de consultation souhaitez-vous ?');
  };

  const handleHangup = () => {
    setIsInCall(false);
    setTranscription('');
    setAiResponse('');
  };

  const handleToggleMute = () => {
    setIsMuted(!isMuted);
  };

  const handleFilterChange = (newFilters: Record<string, any>) => {
    setFilters({ ...filters, ...newFilters });
  };

  const handleSort = (field: string) => {
    if (field === sortField) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const handleViewDetails = (id: string) => {
    console.log('Viewing details for call:', id);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Centre d'Appels</h1>
        <div className="flex items-center space-x-2">
          <div className={`w-3 h-3 rounded-full ${isInCall ? 'bg-green-500' : 'bg-gray-500'}`} />
          <span className="text-sm text-gray-600">
            {isInCall ? 'En appel' : 'En attente'}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <div className="flex justify-center space-x-4">
              {!isInCall ? (
                <Button
                  onClick={handleCall}
                  className="w-16 h-16 rounded-full bg-green-500 hover:bg-green-600"
                >
                  <Phone className="w-8 h-8 text-white" />
                </Button>
              ) : (
                <>
                  <Button
                    onClick={handleToggleMute}
                    className={`w-12 h-12 rounded-full ${
                      isMuted ? 'bg-red-500' : 'bg-blue-500'
                    }`}
                  >
                    <Mic className="w-6 h-6 text-white" />
                  </Button>
                  
                  <Button
                    onClick={handleHangup}
                    className="w-16 h-16 rounded-full bg-red-500 hover:bg-red-600"
                  >
                    <PhoneOff className="w-8 h-8 text-white" />
                  </Button>
                </>
              )}
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h3 className="font-semibold mb-4">Transcription en temps réel</h3>
            <div className="h-48 overflow-y-auto bg-gray-50 rounded p-4">
              {transcription || "En attente de la conversation..."}
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h3 className="font-semibold mb-4">Réponse IA</h3>
          <div className="h-[calc(100%-2rem)] overflow-y-auto bg-gray-50 rounded p-4">
            {aiResponse || "L'IA est prête à assister l'appel..."}
          </div>
        </div>
      </div>

      <CallFilters onFilterChange={handleFilterChange} />
      
      <CallList
        calls={demoData.calls}
        onSort={handleSort}
        onViewDetails={handleViewDetails}
      />
    </div>
  );
}