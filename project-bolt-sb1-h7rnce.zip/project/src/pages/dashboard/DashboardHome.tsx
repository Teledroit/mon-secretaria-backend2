import { Phone, Calendar, Clock, AlertCircle, TrendingUp, Users } from 'lucide-react';
import { Link } from 'react-router-dom';

const stats = [
  { name: 'Appels aujourd\'hui', value: '24', icon: Phone, trend: '+12%' },
  { name: 'Rendez-vous pris', value: '8', icon: Calendar, trend: '+5%' },
  { name: 'Temps moyen d\'appel', value: '2m 30s', icon: Clock, trend: '-8%' },
  { name: 'Taux de conversion', value: '68%', icon: TrendingUp, trend: '+15%' }
];

const recentCalls = [
  { id: 1, name: 'Marie Dupont', time: '14:30', duration: '4:23', status: 'completed', type: 'Consultation initiale' },
  { id: 2, name: 'Jean Martin', time: '13:15', duration: '2:45', status: 'missed', type: 'Question urgente' },
  { id: 3, name: 'Sophie Bernard', time: '11:45', duration: '5:12', status: 'completed', type: 'Suivi dossier' },
  { id: 4, name: 'Pierre Lambert', time: '10:20', duration: '3:30', status: 'completed', type: 'Rendez-vous' }
];

const upcomingAppointments = [
  { id: 1, name: 'Lucas Dubois', time: '15:00', type: 'Consultation', duration: '30min' },
  { id: 2, name: 'Emma Petit', time: '16:30', type: 'Suivi', duration: '45min' }
];

export default function DashboardHome() {
  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Tableau de bord</h1>
        <Link 
          to="/dashboard/calls"
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          Centre d'appels
        </Link>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <div
            key={stat.name}
            className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
          >
            <div className="flex justify-between items-start">
              <div className="p-2 bg-blue-50 rounded-lg">
                <stat.icon className="w-6 h-6 text-blue-600" />
              </div>
              <span className={`text-sm font-medium ${
                stat.trend.startsWith('+') ? 'text-green-600' : 'text-red-600'
              }`}>
                {stat.trend}
              </span>
            </div>
            <div className="mt-4">
              <h3 className="text-sm font-medium text-gray-500">{stat.name}</h3>
              <p className="text-2xl font-semibold mt-1">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h2 className="text-lg font-semibold mb-4">Derniers appels</h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left text-sm text-gray-500">
                    <th className="pb-3">Client</th>
                    <th className="pb-3">Heure</th>
                    <th className="pb-3">Durée</th>
                    <th className="pb-3">Type</th>
                    <th className="pb-3">Statut</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {recentCalls.map((call) => (
                    <tr key={call.id}>
                      <td className="py-3">
                        <div className="flex items-center">
                          <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                            <Users className="w-4 h-4 text-gray-600" />
                          </div>
                          <span className="ml-2 font-medium">{call.name}</span>
                        </div>
                      </td>
                      <td className="py-3">{call.time}</td>
                      <td className="py-3">{call.duration}</td>
                      <td className="py-3">{call.type}</td>
                      <td className="py-3">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          call.status === 'completed' 
                            ? 'bg-green-100 text-green-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {call.status === 'completed' ? 'Terminé' : 'Manqué'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h2 className="text-lg font-semibold mb-4">Prochains rendez-vous</h2>
            <div className="space-y-4">
              {upcomingAppointments.map((appointment) => (
                <div 
                  key={appointment.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                >
                  <div>
                    <p className="font-medium">{appointment.name}</p>
                    <p className="text-sm text-gray-500">{appointment.type}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">{appointment.time}</p>
                    <p className="text-sm text-gray-500">{appointment.duration}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}