import { useState, useEffect } from 'react';
import { Calendar, Clock, Users } from 'lucide-react';
import Button from '@/components/ui/Button';
import CalendarConnect from '@/components/appointments/CalendarConnect';
import { listEvents } from '@/lib/calendar/events';
import { getStoredCredentials } from '@/lib/calendar/auth';

// Données de démonstration
const demoAppointments = [
  {
    id: 1,
    client: 'Marie Dupont',
    date: '2024-03-20',
    time: '14:30',
    duration: '45min',
    type: 'Consultation initiale',
    status: 'confirmed'
  },
  {
    id: 2,
    client: 'Jean Martin',
    date: '2024-03-21',
    time: '10:00',
    duration: '30min',
    type: 'Suivi dossier',
    status: 'pending'
  }
];

export default function Appointments() {
  const [isCalendarConnected, setIsCalendarConnected] = useState(false);
  const [appointments, setAppointments] = useState(demoAppointments);
  const [selectedDate, setSelectedDate] = useState(new Date());

  useEffect(() => {
    const credentials = getStoredCredentials();
    setIsCalendarConnected(!!credentials);
  }, []);

  useEffect(() => {
    if (isCalendarConnected) {
      loadAppointments();
    }
  }, [isCalendarConnected]);

  const loadAppointments = async () => {
    try {
      const timeMin = new Date();
      const timeMax = new Date();
      timeMax.setMonth(timeMax.getMonth() + 1);
      
      const events = await listEvents(timeMin, timeMax);
      // Fusionner les événements Google Calendar avec les rendez-vous existants
      const googleEvents = (events.items || []).map(event => ({
        id: event.id,
        client: event.summary,
        date: new Date(event.start.dateTime).toISOString().split('T')[0],
        time: new Date(event.start.dateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        duration: getDuration(event.start.dateTime, event.end.dateTime),
        type: event.description || 'Rendez-vous',
        status: 'confirmed'
      }));
      
      setAppointments([...demoAppointments, ...googleEvents]);
    } catch (error) {
      console.error('Error loading appointments:', error);
    }
  };

  const handleCalendarConnect = () => {
    setIsCalendarConnected(!isCalendarConnected);
  };

  const getDuration = (start: string, end: string) => {
    const diff = new Date(end).getTime() - new Date(start).getTime();
    return `${Math.round(diff / (1000 * 60))}min`;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Rendez-vous</h1>
        <Button>
          Nouveau rendez-vous
        </Button>
      </div>

      <CalendarConnect 
        onConnect={handleCalendarConnect}
        isConnected={isCalendarConnected}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h2 className="text-lg font-semibold mb-6">Prochains rendez-vous</h2>
            <div className="space-y-4">
              {appointments.map((appointment) => (
                <div
                  key={appointment.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <Users className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">{appointment.client}</h3>
                      <p className="text-sm text-gray-500">{appointment.type}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">
                      {appointment.date} à {appointment.time}
                    </p>
                    <p className="text-sm text-gray-500">
                      Durée : {appointment.duration}
                    </p>
                  </div>
                  <div>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      appointment.status === 'confirmed' 
                        ? 'bg-green-100 text-green-800'
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {appointment.status === 'confirmed' ? 'Confirmé' : 'En attente'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div>
          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h2 className="text-lg font-semibold mb-6">Statistiques</h2>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <Calendar className="w-5 h-5 text-blue-600" />
                  <span>Rendez-vous ce mois</span>
                </div>
                <span className="font-medium">{appointments.length}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <Clock className="w-5 h-5 text-blue-600" />
                  <span>Durée moyenne</span>
                </div>
                <span className="font-medium">45min</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}