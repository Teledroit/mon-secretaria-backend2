import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { handleAuthCallback, setStoredCredentials } from '@/lib/calendar/auth';

export default function CalendarCallback() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const code = searchParams.get('code');
    if (!code) {
      setError('Code d\'autorisation manquant');
      return;
    }

    handleAuthCallback(code)
      .then((credentials) => {
        setStoredCredentials(credentials);
        navigate('/dashboard/appointments');
      })
      .catch((err) => {
        console.error('Error handling callback:', err);
        setError('Erreur lors de la connexion à Google Calendar');
      });
  }, [searchParams, navigate]);

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-red-600 mb-4">Erreur</h1>
          <p className="text-gray-600">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-2xl font-bold mb-4">Connexion en cours...</h1>
        <p className="text-gray-600">Veuillez patienter pendant la configuration de Google Calendar</p>
      </div>
    </div>
  );
}