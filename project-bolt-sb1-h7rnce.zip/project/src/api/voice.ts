import express from 'express';
import { handleIncomingCall, handleTranscription, handleCallStatus } from '../lib/services/twilioWebhook';

const router = express.Router();

router.post('/voice', handleIncomingCall);
router.post('/transcribe', handleTranscription);
router.post('/status', handleCallStatus);

export default router;