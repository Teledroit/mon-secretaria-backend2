import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './lib/AuthContext';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import Hero from './components/home/Hero';
import Features from './components/home/Features';
import Benefits from './components/home/Benefits';
import Demo from './components/home/Demo';
import Savings from './components/home/Savings';
import Pricing from './components/home/Pricing';
import Testimonials from './components/home/Testimonials';
import FAQ from './components/home/FAQ';
import Contact from './components/home/Contact';
import DashboardLayout from './components/dashboard/DashboardLayout';
import DashboardHome from './pages/dashboard/DashboardHome';
import CallCenter from './pages/dashboard/CallCenter';
import Appointments from './pages/dashboard/Appointments';
import Settings from './pages/dashboard/Settings';
import Billing from './pages/dashboard/Billing';
import PhoneLine from './pages/dashboard/PhoneLine';
import Notifications from './pages/dashboard/Notifications';
import LoginPage from './pages/auth/LoginPage';
import RegisterPage from './pages/auth/RegisterPage';
import AuthGuard from './components/auth/AuthGuard';

function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <Hero />
        <Features />
        <Benefits />
        <Demo />
        <Savings />
        <Testimonials />
        <Pricing />
        <FAQ />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/dashboard" element={
            <AuthGuard>
              <DashboardLayout />
            </AuthGuard>
          }>
            <Route index element={<DashboardHome />} />
            <Route path="calls" element={<CallCenter />} />
            <Route path="appointments" element={<Appointments />} />
            <Route path="line" element={<PhoneLine />} />
            <Route path="settings" element={<Settings />} />
            <Route path="notifications" element={<Notifications />} />
            <Route path="billing" element={<Billing />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}