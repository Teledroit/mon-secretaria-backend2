import { BarChart3, Clock, TrendingUp } from 'lucide-react';

interface UsageSummaryProps {
  currentUsage: {
    minutes: number;
    cost: number;
    averageCost: number;
  };
  limits: {
    minutes: number;
    remaining: number;
  };
}

export default function UsageSummary({ currentUsage, limits }: UsageSummaryProps) {
  const usagePercentage = (currentUsage.minutes / limits.minutes) * 100;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
        <div className="flex items-center justify-between mb-4">
          <Clock className="w-5 h-5 text-blue-600" />
          <span className="text-sm text-gray-500">Ce mois-ci</span>
        </div>
        <div className="space-y-2">
          <p className="text-2xl font-semibold">{currentUsage.minutes} min</p>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-blue-600 h-2 rounded-full" 
              style={{ width: `${usagePercentage}%` }}
            />
          </div>
          <p className="text-sm text-gray-600">
            {limits.remaining} minutes restantes
          </p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
        <div className="flex items-center justify-between mb-4">
          <BarChart3 className="w-5 h-5 text-blue-600" />
          <span className="text-sm text-gray-500">Coût total</span>
        </div>
        <p className="text-2xl font-semibold">{currentUsage.cost}€</p>
        <p className="text-sm text-gray-600 mt-2">
          Hors forfait inclus
        </p>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
        <div className="flex items-center justify-between mb-4">
          <TrendingUp className="w-5 h-5 text-blue-600" />
          <span className="text-sm text-gray-500">Coût moyen</span>
        </div>
        <p className="text-2xl font-semibold">{currentUsage.averageCost}€</p>
        <p className="text-sm text-gray-600 mt-2">
          Par minute
        </p>
      </div>
    </div>
  );
}