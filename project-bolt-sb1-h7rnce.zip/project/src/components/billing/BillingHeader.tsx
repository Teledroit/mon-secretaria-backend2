import { CreditCard, Download } from 'lucide-react';
import Button from '@/components/ui/Button';

interface BillingHeaderProps {
  currentPlan: string;
  isOverdue: boolean;
}

export default function BillingHeader({ currentPlan, isOverdue }: BillingHeaderProps) {
  return (
    <div className="flex justify-between items-start mb-6">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900">Facturation</h1>
        <p className="text-sm text-gray-600 mt-1">
          Plan actuel : <span className="font-medium">{currentPlan}</span>
        </p>
      </div>
      {isOverdue && (
        <div className="bg-red-50 text-red-700 px-4 py-2 rounded-lg text-sm flex items-center">
          <span className="font-medium">Compte bloqué : facture(s) impayée(s)</span>
        </div>
      )}
    </div>
  );
}