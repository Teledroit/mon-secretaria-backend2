import { CreditCard, Plus, Trash2 } from 'lucide-react';
import Button from '@/components/ui/Button';

interface PaymentMethod {
  id: string;
  type: 'card' | 'sepa';
  last4: string;
  expiryDate?: string;
  isDefault: boolean;
}

interface PaymentMethodsProps {
  methods: PaymentMethod[];
  onAddMethod: () => void;
  onRemoveMethod: (id: string) => void;
  onSetDefault: (id: string) => void;
}

export default function PaymentMethods({ 
  methods, 
  onAddMethod, 
  onRemoveMethod, 
  onSetDefault 
}: PaymentMethodsProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-medium">Moyens de paiement</h3>
        <Button onClick={onAddMethod} size="sm">
          <Plus className="w-4 h-4 mr-2" />
          Ajouter
        </Button>
      </div>

      <div className="space-y-4">
        {methods.map((method) => (
          <div 
            key={method.id}
            className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
          >
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                <CreditCard className="w-6 h-6 text-gray-600" />
              </div>
              <div>
                <p className="font-medium">
                  {method.type === 'card' ? 'Carte' : 'Prélèvement SEPA'} 
                  •••• {method.last4}
                </p>
                {method.expiryDate && (
                  <p className="text-sm text-gray-500">
                    Expire le {method.expiryDate}
                  </p>
                )}
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {!method.isDefault && (
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => onSetDefault(method.id)}
                >
                  Définir par défaut
                </Button>
              )}
              {method.isDefault && (
                <span className="text-sm text-blue-600 font-medium">
                  Par défaut
                </span>
              )}
              {!method.isDefault && (
                <button
                  onClick={() => onRemoveMethod(method.id)}
                  className="text-gray-400 hover:text-red-600"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}