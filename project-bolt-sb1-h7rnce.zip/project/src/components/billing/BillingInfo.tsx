import { Building2, Mail } from 'lucide-react';
import Button from '@/components/ui/Button';

interface BillingInfoProps {
  info: {
    companyName: string;
    address: string;
    city: string;
    postalCode: string;
    country: string;
    vatNumber: string;
    email: string;
  };
  onEdit: () => void;
}

export default function BillingInfo({ info, onEdit }: BillingInfoProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-medium">Informations de facturation</h3>
        <Button variant="outline" size="sm" onClick={onEdit}>
          Modifier
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <div className="flex items-center space-x-2 mb-3">
            <Building2 className="w-5 h-5 text-gray-400" />
            <span className="font-medium">Entreprise</span>
          </div>
          <div className="space-y-2 text-gray-600">
            <p>{info.companyName}</p>
            <p>{info.address}</p>
            <p>{info.city}, {info.postalCode}</p>
            <p>{info.country}</p>
            {info.vatNumber && (
              <p className="text-sm">TVA : {info.vatNumber}</p>
            )}
          </div>
        </div>

        <div>
          <div className="flex items-center space-x-2 mb-3">
            <Mail className="w-5 h-5 text-gray-400" />
            <span className="font-medium">Email de facturation</span>
          </div>
          <p className="text-gray-600">{info.email}</p>
        </div>
      </div>
    </div>
  );
}