import { useState } from 'react';
import { Calendar, Link as LinkIcon } from 'lucide-react';
import Button from '@/components/ui/Button';
import { getAuthUrl } from '@/lib/calendar/auth';

interface CalendarConnectProps {
  onConnect: () => void;
  isConnected: boolean;
}

export default function CalendarConnect({ onConnect, isConnected }: CalendarConnectProps) {
  const [isConnecting, setIsConnecting] = useState(false);

  const handleConnect = async () => {
    try {
      setIsConnecting(true);
      const authUrl = getAuthUrl();
      window.location.href = authUrl;
    } catch (error) {
      console.error('Error connecting to Google Calendar:', error);
    } finally {
      setIsConnecting(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
      <div className="flex items-center gap-2 mb-6">
        <Calendar className="w-5 h-5 text-blue-600" />
        <h2 className="text-lg font-medium">Google Calendar</h2>
      </div>

      {!isConnected ? (
        <div className="text-center">
          <p className="text-gray-600 mb-4">
            Connectez votre Google Calendar pour synchroniser vos rendez-vous
          </p>
          <Button
            onClick={handleConnect}
            disabled={isConnecting}
            className="flex items-center justify-center"
          >
            <LinkIcon className="w-4 h-4 mr-2" />
            {isConnecting ? 'Connexion...' : 'Connecter Google Calendar'}
          </Button>
        </div>
      ) : (
        <div className="text-center">
          <div className="flex items-center justify-center gap-2 text-green-600 mb-4">
            <div className="w-2 h-2 bg-green-500 rounded-full" />
            <span>Connecté à Google Calendar</span>
          </div>
          <Button variant="outline" onClick={onConnect}>
            Déconnecter
          </Button>
        </div>
      )}
    </div>
  );
}