import { useState } from 'react';
import { Network } from 'lucide-react';
import Button from '@/components/ui/Button';

interface SIPConfig {
  phoneNumber: string;
  terminationUri: string;
  username: string;
  password: string;
  nickname?: string;
}

export default function ConnectSIP() {
  const [config, setConfig] = useState<SIPConfig>({
    phoneNumber: '',
    terminationUri: '',
    username: '',
    password: '',
    nickname: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Configuration SIP:', config);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Numéro de téléphone
        </label>
        <input
          type="tel"
          value={config.phoneNumber}
          onChange={(e) => setConfig({ ...config, phoneNumber: e.target.value })}
          placeholder="+33123456789"
          className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          URI de terminaison
        </label>
        <input
          type="text"
          value={config.terminationUri}
          onChange={(e) => setConfig({ ...config, terminationUri: e.target.value })}
          placeholder="sip:example.com"
          className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Nom d'utilisateur SIP
        </label>
        <input
          type="text"
          value={config.username}
          onChange={(e) => setConfig({ ...config, username: e.target.value })}
          className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Mot de passe SIP
        </label>
        <input
          type="password"
          value={config.password}
          onChange={(e) => setConfig({ ...config, password: e.target.value })}
          className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Surnom (optionnel)
        </label>
        <input
          type="text"
          value={config.nickname}
          onChange={(e) => setConfig({ ...config, nickname: e.target.value })}
          placeholder="Ex: Bureau principal"
          className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        />
      </div>

      <Button type="submit" className="w-full">
        <Network className="w-4 h-4 mr-2" />
        Connecter la ligne SIP
      </Button>
    </form>
  );
}