import { useState } from 'react';
import { Phone, Search } from 'lucide-react';
import Button from '@/components/ui/Button';

interface PhoneNumber {
  number: string;
  location: string;
  type: 'local' | 'mobile' | 'tollfree';
  price: number;
}

export default function BuyPhoneNumber() {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [availableNumbers, setAvailableNumbers] = useState<PhoneNumber[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Simuler une recherche de numéros disponibles via l'API Twilio
  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      setError("Veuillez entrer une ville ou un indicatif");
      return;
    }

    setError(null);
    setIsSearching(true);

    try {
      // Dans une vraie implémentation, ceci serait un appel à l'API Twilio
      // pour rechercher des numéros disponibles dans la région spécifiée
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Simulation de résultats
      setAvailableNumbers([
        { 
          number: `+33 ${Math.floor(Math.random() * 10)}${Math.floor(Math.random() * 10)} ${Math.floor(Math.random() * 100)} ${Math.floor(Math.random() * 100)} ${Math.floor(Math.random() * 100)}`, 
          location: searchQuery, 
          type: 'local', 
          price: 1.99 
        },
        { 
          number: `+33 ${Math.floor(Math.random() * 10)}${Math.floor(Math.random() * 10)} ${Math.floor(Math.random() * 100)} ${Math.floor(Math.random() * 100)} ${Math.floor(Math.random() * 100)}`, 
          location: searchQuery, 
          type: 'local', 
          price: 1.99 
        },
        { 
          number: `+33 ${Math.floor(Math.random() * 10)}${Math.floor(Math.random() * 10)} ${Math.floor(Math.random() * 100)} ${Math.floor(Math.random() * 100)} ${Math.floor(Math.random() * 100)}`, 
          location: searchQuery, 
          type: 'mobile', 
          price: 2.99 
        },
      ]);
    } catch (err) {
      setError("Une erreur est survenue lors de la recherche de numéros");
    } finally {
      setIsSearching(false);
    }
  };

  const handlePurchase = async (number: PhoneNumber) => {
    try {
      // Dans une vraie implémentation, ceci serait un appel à l'API Twilio
      // pour acheter le numéro et l'associer au compte du client
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Simuler une confirmation
      alert(`Numéro ${number.number} acheté avec succès !`);
      
      // Retirer le numéro de la liste des disponibles
      setAvailableNumbers(numbers => numbers.filter(n => n.number !== number.number));
    } catch (err) {
      setError("Une erreur est survenue lors de l'achat du numéro");
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex gap-4">
        <div className="flex-1">
          <input
            type="text"
            placeholder="Rechercher par ville (ex: Paris, Lyon...)"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
          {error && (
            <p className="mt-1 text-sm text-red-600">{error}</p>
          )}
        </div>
        <Button 
          onClick={handleSearch} 
          disabled={isSearching}
        >
          <Search className="w-4 h-4 mr-2" />
          {isSearching ? 'Recherche...' : 'Rechercher'}
        </Button>
      </div>

      {availableNumbers.length > 0 && (
        <div className="space-y-4">
          <h3 className="font-medium">Numéros disponibles</h3>
          <div className="grid gap-4">
            {availableNumbers.map((number) => (
              <div
                key={number.number}
                className="flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200"
              >
                <div className="flex items-center space-x-4">
                  <div className="p-2 bg-blue-50 rounded-lg">
                    <Phone className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-medium">{number.number}</p>
                    <p className="text-sm text-gray-500">
                      {number.location} • {number.type === 'local' ? 'Local' : 'Mobile'}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <p className="font-medium">{number.price}€/mois</p>
                  <Button onClick={() => handlePurchase(number)}>
                    Acheter
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}