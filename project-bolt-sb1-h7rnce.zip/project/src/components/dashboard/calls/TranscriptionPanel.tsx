import { MessageSquare } from 'lucide-react';

interface TranscriptionPanelProps {
  transcription: string;
}

export default function TranscriptionPanel({ transcription }: TranscriptionPanelProps) {
  return (
    <div className="bg-gray-50 rounded-lg p-4">
      <h3 className="font-semibold mb-2 flex items-center">
        <MessageSquare className="w-5 h-5 mr-2" />
        Transcription en temps réel
      </h3>
      <div className="h-48 overflow-y-auto bg-white rounded p-3 border">
        {transcription || "En attente de la conversation..."}
      </div>
    </div>
  );
}