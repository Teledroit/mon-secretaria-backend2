import { Phone, Clock, TrendingUp, AlertCircle } from 'lucide-react';
import Button from '@/components/ui/Button';

interface Call {
  id: string;
  date: string;
  time: string;
  duration: string;
  type: string;
  cost: number;
  status: string;
  sentiment: string;
  from: string;
  to: string;
  successful: boolean;
  latency: number;
}

interface CallListProps {
  calls: Call[];
  onSort: (field: string) => void;
  onViewDetails: (id: string) => void;
}

export default function CallList({ calls, onSort, onViewDetails }: CallListProps) {
  const getSentimentColor = (sentiment: string) => {
    const colors = {
      positive: 'bg-green-100 text-green-800',
      neutral: 'bg-gray-100 text-gray-800',
      negative: 'bg-red-100 text-red-800'
    };
    return colors[sentiment as keyof typeof colors] || colors.neutral;
  };

  const getStatusColor = (status: string) => {
    const colors = {
      success: 'bg-green-100 text-green-800',
      failed: 'bg-red-100 text-red-800',
      'in-progress': 'bg-blue-100 text-blue-800'
    };
    return colors[status as keyof typeof colors] || colors.neutral;
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="text-left text-sm text-gray-500 border-b border-gray-100">
              <th className="px-6 py-3 cursor-pointer hover:text-gray-700" onClick={() => onSort('date')}>
                Date/Heure
              </th>
              <th className="px-6 py-3 cursor-pointer hover:text-gray-700" onClick={() => onSort('duration')}>
                Durée
              </th>
              <th className="px-6 py-3 cursor-pointer hover:text-gray-700" onClick={() => onSort('type')}>
                Type
              </th>
              <th className="px-6 py-3 cursor-pointer hover:text-gray-700" onClick={() => onSort('cost')}>
                Coût
              </th>
              <th className="px-6 py-3">Status</th>
              <th className="px-6 py-3">Sentiment</th>
              <th className="px-6 py-3">De</th>
              <th className="px-6 py-3">Vers</th>
              <th className="px-6 py-3">Latence</th>
              <th className="px-6 py-3">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {calls.map((call) => (
              <tr key={call.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div>
                    <div className="font-medium">{call.date}</div>
                    <div className="text-sm text-gray-500">{call.time}</div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 text-gray-400 mr-2" />
                    {call.duration}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {call.type}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <TrendingUp className="w-4 h-4 text-gray-400 mr-2" />
                    {call.cost}€
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(call.status)}`}>
                    {call.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getSentimentColor(call.sentiment)}`}>
                    {call.sentiment}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {call.from}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {call.to}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {call.latency}ms
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onViewDetails(call.id)}
                  >
                    Détails
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}