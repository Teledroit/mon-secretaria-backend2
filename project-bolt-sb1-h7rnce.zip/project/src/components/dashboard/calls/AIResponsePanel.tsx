import { Brain } from 'lucide-react';

interface AIResponsePanelProps {
  response: string;
}

export default function AIResponsePanel({ response }: AIResponsePanelProps) {
  return (
    <div className="bg-gray-50 rounded-lg p-4">
      <h3 className="font-semibold mb-2 flex items-center">
        <Brain className="w-5 h-5 mr-2" />
        Réponse IA
      </h3>
      <div className="h-64 overflow-y-auto bg-white rounded p-3 border">
        {response || "L'IA est prête à assister l'appel..."}
      </div>
    </div>
  );
}