import { Phone, Mic, PhoneOff } from 'lucide-react';
import Button from '@/components/ui/Button';

interface CallControlsProps {
  isReady: boolean;
  connection: any;
  isMuted: boolean;
  onCall: () => void;
  onHangup: () => void;
  onToggleMute: () => void;
}

export default function CallControls({
  isReady,
  connection,
  isMuted,
  onCall,
  onHangup,
  onToggleMute
}: CallControlsProps) {
  return (
    <div className="flex items-center justify-center space-x-4">
      <Button
        onClick={onCall}
        disabled={!isReady || connection}
        className={`w-16 h-16 rounded-full ${
          !connection ? 'bg-green-500 hover:bg-green-600' : 'bg-gray-300'
        }`}
      >
        <Phone className="w-8 h-8 text-white" />
      </Button>
      
      {connection && (
        <>
          <Button
            onClick={onToggleMute}
            className={`w-12 h-12 rounded-full ${
              isMuted ? 'bg-red-500' : 'bg-blue-500'
            }`}
          >
            <Mic className="w-6 h-6 text-white" />
          </Button>
          
          <Button
            onClick={onHangup}
            className="w-16 h-16 rounded-full bg-red-500 hover:bg-red-600"
          >
            <PhoneOff className="w-8 h-8 text-white" />
          </Button>
        </>
      )}
    </div>
  );
}