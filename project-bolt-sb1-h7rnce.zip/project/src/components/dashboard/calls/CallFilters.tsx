import { Search, Filter } from 'lucide-react';
import Button from '@/components/ui/Button';

interface FilterOption {
  id: string;
  label: string;
  type: 'text' | 'select' | 'date' | 'number' | 'boolean';
  options?: { value: string; label: string }[];
}

const filterOptions: FilterOption[] = [
  { id: 'date', label: 'Date', type: 'date' },
  { id: 'duration', label: 'Durée', type: 'number' },
  { id: 'type', label: 'Type', type: 'select', options: [
    { value: 'incoming', label: 'Entrant' },
    { value: 'outgoing', label: 'Sortant' },
    { value: 'missed', label: 'Manqué' }
  ]},
  { id: 'cost', label: 'Coût', type: 'number' },
  { id: 'callId', label: 'ID Appel', type: 'text' },
  { id: 'disconnectReason', label: 'Raison de déconnexion', type: 'select', options: [
    { value: 'completed', label: 'Terminé' },
    { value: 'canceled', label: 'Annulé' },
    { value: 'failed', label: 'Échoué' }
  ]},
  { id: 'status', label: 'Statut', type: 'select', options: [
    { value: 'success', label: 'Réussi' },
    { value: 'failed', label: 'Échoué' },
    { value: 'in-progress', label: 'En cours' }
  ]},
  { id: 'sentiment', label: 'Sentiment utilisateur', type: 'select', options: [
    { value: 'positive', label: 'Positif' },
    { value: 'neutral', label: 'Neutre' },
    { value: 'negative', label: 'Négatif' }
  ]},
  { id: 'from', label: 'De', type: 'text' },
  { id: 'to', label: 'Vers', type: 'text' },
  { id: 'successful', label: 'Appel réussi', type: 'boolean' },
  { id: 'latency', label: 'Latence', type: 'number' }
];

interface CallFiltersProps {
  onFilterChange: (filters: Record<string, any>) => void;
}

export default function CallFilters({ onFilterChange }: CallFiltersProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-medium">Filtres</h3>
        <Button variant="outline" size="sm">
          <Filter className="w-4 h-4 mr-2" />
          Réinitialiser
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filterOptions.map((filter) => (
          <div key={filter.id}>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {filter.label}
            </label>
            {filter.type === 'select' ? (
              <select
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                onChange={(e) => onFilterChange({ [filter.id]: e.target.value })}
              >
                <option value="">Tous</option>
                {filter.options?.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            ) : filter.type === 'boolean' ? (
              <select
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                onChange={(e) => onFilterChange({ [filter.id]: e.target.value })}
              >
                <option value="">Tous</option>
                <option value="true">Oui</option>
                <option value="false">Non</option>
              </select>
            ) : (
              <input
                type={filter.type}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                onChange={(e) => onFilterChange({ [filter.id]: e.target.value })}
              />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}