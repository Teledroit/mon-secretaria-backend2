import { useState } from 'react';
import { FileText, Upload, Link as LinkIcon, Plus } from 'lucide-react';
import Button from '@/components/ui/Button';

interface Document {
  id: string;
  name: string;
  type: 'pdf' | 'url';
  content: string;
}

export default function DocumentsConfig() {
  const [documents, setDocuments] = useState<Document[]>([]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const newDoc: Document = {
        id: Date.now().toString(),
        name: file.name,
        type: 'pdf',
        content: URL.createObjectURL(file)
      };
      setDocuments([...documents, newDoc]);
    }
  };

  const handleUrlAdd = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const url = formData.get('url') as string;
    const name = formData.get('name') as string;
    
    if (url && name) {
      const newDoc: Document = {
        id: Date.now().toString(),
        name,
        type: 'url',
        content: url
      };
      setDocuments([...documents, newDoc]);
      (e.target as HTMLFormElement).reset();
    }
  };

  const removeDocument = (id: string) => {
    setDocuments(documents.filter(doc => doc.id !== id));
  };

  return (
    <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
      <div className="flex items-center gap-2 mb-6">
        <FileText className="w-5 h-5 text-blue-600" />
        <h2 className="text-lg font-medium">Documents d'Instructions</h2>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Ajouter un PDF d'instructions
          </label>
          <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
            <div className="space-y-1 text-center">
              <Upload className="mx-auto h-12 w-12 text-gray-400" />
              <div className="flex text-sm text-gray-600">
                <label className="relative cursor-pointer rounded-md font-medium text-blue-600 hover:text-blue-500">
                  <span>Télécharger un fichier</span>
                  <input type="file" className="sr-only" accept=".pdf" onChange={handleFileUpload} />
                </label>
              </div>
              <p className="text-xs text-gray-500">PDF jusqu'à 10MB</p>
            </div>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Ajouter une URL d'instructions
          </label>
          <form onSubmit={handleUrlAdd} className="flex gap-2">
            <input
              type="text"
              name="name"
              placeholder="Nom du document"
              className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
            <input
              type="url"
              name="url"
              placeholder="https://..."
              className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
            <Button type="submit" size="sm">
              <Plus className="w-4 h-4" />
            </Button>
          </form>
        </div>

        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-2">Documents ajoutés</h3>
          <div className="space-y-2">
            {documents.map(doc => (
              <div key={doc.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                <div className="flex items-center gap-2">
                  {doc.type === 'pdf' ? (
                    <FileText className="w-4 h-4 text-gray-500" />
                  ) : (
                    <LinkIcon className="w-4 h-4 text-gray-500" />
                  )}
                  <span className="text-sm text-gray-700">{doc.name}</span>
                </div>
                <button
                  onClick={() => removeDocument(doc.id)}
                  className="text-red-600 hover:text-red-700 text-sm"
                >
                  Supprimer
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}