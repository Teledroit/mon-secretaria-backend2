import { useState } from 'react';
import { GitBranch, Plus, Trash2 } from 'lucide-react';
import Button from '@/components/ui/Button';

interface Step {
  id: string;
  type: 'prompt' | 'condition' | 'action';
  content: string;
  next?: string;
}

export default function WorkflowConfig() {
  const [steps, setSteps] = useState<Step[]>([]);
  const [selectedType, setSelectedType] = useState<Step['type']>('prompt');

  const addStep = () => {
    const newStep: Step = {
      id: Date.now().toString(),
      type: selectedType,
      content: '',
    };
    setSteps([...steps, newStep]);
  };

  const updateStep = (id: string, content: string) => {
    setSteps(steps.map(step => 
      step.id === id ? { ...step, content } : step
    ));
  };

  const removeStep = (id: string) => {
    setSteps(steps.filter(step => step.id !== id));
  };

  return (
    <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
      <div className="flex items-center gap-2 mb-6">
        <GitBranch className="w-5 h-5 text-blue-600" />
        <h2 className="text-lg font-medium">Configuration du Workflow</h2>
      </div>

      <div className="space-y-6">
        <div className="flex gap-4 items-end">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Type d'étape
            </label>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value as Step['type'])}
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="prompt">Prompt</option>
              <option value="condition">Condition</option>
              <option value="action">Action</option>
            </select>
          </div>
          <Button onClick={addStep}>
            <Plus className="w-4 h-4 mr-2" />
            Ajouter une étape
          </Button>
        </div>

        <div className="space-y-4">
          {steps.map((step, index) => (
            <div key={step.id} className="relative border rounded-lg p-4 bg-gray-50">
              <div className="absolute -left-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-blue-600 rounded-full text-white flex items-center justify-center text-sm">
                {index + 1}
              </div>
              <div className="ml-4">
                <div className="flex justify-between items-start mb-2">
                  <span className="text-sm font-medium text-gray-700">
                    {step.type.charAt(0).toUpperCase() + step.type.slice(1)}
                  </span>
                  <button
                    onClick={() => removeStep(step.id)}
                    className="text-gray-400 hover:text-red-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <textarea
                  value={step.content}
                  onChange={(e) => updateStep(step.id, e.target.value)}
                  placeholder={
                    step.type === 'prompt' ? "Entrez le prompt..." :
                    step.type === 'condition' ? "Définissez la condition..." :
                    "Décrivez l'action..."
                  }
                  rows={3}
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}