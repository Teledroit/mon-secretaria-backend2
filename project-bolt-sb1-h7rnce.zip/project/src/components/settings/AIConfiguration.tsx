import { useState } from 'react';
import { Brain } from 'lucide-react';
import Button from '@/components/ui/Button';

interface AIConfigurationProps {
  onSave: (data: any) => void;
}

export default function AIConfiguration({ onSave }: AIConfigurationProps) {
  const [prompt, setPrompt] = useState('');
  const [systemInstructions, setSystemInstructions] = useState('');
  const [temperature, setTemperature] = useState(0.7);

  const handleSave = () => {
    onSave({
      prompt,
      systemInstructions,
      temperature
    });
  };

  return (
    <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
      <div className="flex items-center gap-2 mb-6">
        <Brain className="w-5 h-5 text-blue-600" />
        <h2 className="text-lg font-medium">Configuration de l'IA</h2>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Instructions système (prompt principal)
          </label>
          <textarea
            value={systemInstructions}
            onChange={(e) => setSystemInstructions(e.target.value)}
            rows={4}
            placeholder="Définissez le comportement général de l'assistant..."
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Prompt par défaut
          </label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={3}
            placeholder="Prompt utilisé pour initier chaque conversation..."
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Température (créativité)
          </label>
          <div className="flex items-center gap-4">
            <input
              type="range"
              min="0"
              max="1"
              step="0.1"
              value={temperature}
              onChange={(e) => setTemperature(parseFloat(e.target.value))}
              className="w-full"
            />
            <span className="text-sm text-gray-600 w-12">{temperature}</span>
          </div>
        </div>

        <Button onClick={handleSave} className="w-full">
          Sauvegarder la configuration IA
        </Button>
      </div>
    </div>
  );
}