import { Navigate } from 'react-router-dom';

export default function AuthGuard({ children }: { children: React.ReactNode }) {
  // Pour la démo, on considère toujours l'utilisateur comme authentifié
  return <>{children}</>;
}