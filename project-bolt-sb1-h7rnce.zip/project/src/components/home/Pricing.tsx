import { Check } from 'lucide-react';
import Button from '../ui/Button';

const plans = [
  {
    name: "Essentiel",
    price: "49",
    minutePrice: "0.15",
    description: "Parfait pour les cabinets individuels",
    features: [
      "1 ligne téléphonique",
      "Prise de rendez-vous basique",
      "Voix IA standard",
      "Transfert d'appels",
      "Support par email",
      "880 minutes incluses"
    ]
  },
  {
    name: "Pro",
    price: "99",
    minutePrice: "0.15",
    description: "Idéal pour les petits cabinets",
    features: [
      "3 lignes téléphoniques",
      "Intégration Calendly avancée",
      "Personnalisation vocale complète",
      "Rapports détaillés",
      "Support prioritaire",
      "Configuration personnalisée",
      "2000 minutes incluses"
    ],
    popular: true
  },
  {
    name: "Enterprise",
    price: "Sur mesure",
    minutePrice: "0.12",
    description: "Pour les grands cabinets d'avocats",
    features: [
      "Lignes illimitées",
      "API personnalisée",
      "Voix IA sur mesure",
      "Formation dédiée",
      "Support 24/7",
      "SLA garanti",
      "Minutes illimitées"
    ]
  }
];

export default function Pricing() {
  return (
    <section id="pricing" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-4">
          Tarifs Adaptés à Vos Besoins
        </h2>
        <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
          Choisissez le plan qui correspond à votre volume d'appels. 
          Tous les plans incluent un tarif de {plans[0].minutePrice}€/minute au-delà des minutes incluses.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {plans.map((plan) => (
            <div 
              key={plan.name}
              className={`bg-white rounded-lg p-8 ${
                plan.popular ? 'ring-2 ring-blue-500 shadow-lg' : 'border'
              }`}
            >
              {plan.popular && (
                <span className="bg-blue-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                  Populaire
                </span>
              )}
              <h3 className="text-2xl font-bold mt-4">{plan.name}</h3>
              <div className="mt-4 flex items-baseline">
                <span className="text-4xl font-bold">{plan.price}</span>
                {plan.price !== "Sur mesure" && (
                  <span className="ml-1 text-gray-500">€/mois</span>
                )}
              </div>
              {plan.minutePrice && plan.price !== "Sur mesure" && (
                <p className="mt-2 text-sm text-gray-500">
                  + {plan.minutePrice}€/min au-delà des minutes incluses
                </p>
              )}
              <p className="mt-4 text-gray-500">{plan.description}</p>
              <ul className="mt-6 space-y-4">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center">
                    <Check className="h-5 w-5 text-blue-500 mr-2" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              <Button 
                variant={plan.popular ? 'primary' : 'outline'}
                className="w-full mt-8"
              >
                {plan.price === "Sur mesure" ? "Contactez-nous" : "Commencer"}
              </Button>
            </div>
          ))}
        </div>

        <div className="bg-blue-50 rounded-xl p-8 text-center">
          <p className="text-sm text-blue-600 font-medium mb-2">Information</p>
          <p className="text-gray-600">
            Ces tarifs sont donnés à titre indicatif et peuvent être adaptés selon vos besoins spécifiques.
            Contactez-nous pour une étude personnalisée de votre situation.
          </p>
        </div>
      </div>
    </section>
  );
}