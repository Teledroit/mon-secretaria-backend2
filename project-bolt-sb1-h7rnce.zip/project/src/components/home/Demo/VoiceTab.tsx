import { useState } from 'react';
import Button from '../../ui/Button';

interface VoiceTabProps {
  onVoiceTypeChange?: (value: string) => void;
  onWelcomeMessageChange?: (value: string) => void;
}

export default function VoiceTab({ onVoiceTypeChange, onWelcomeMessageChange }: VoiceTabProps) {
  const [voiceType, setVoiceType] = useState('Femme - Professionnelle (25-35 ans)');
  const [welcomeMessage, setWelcomeMessage] = useState(
    "Bonjour, vous êtes en communication avec l'assistant virtuel du cabinet. Comment puis-je vous aider ?"
  );

  const handleVoiceTypeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setVoiceType(e.target.value);
    onVoiceTypeChange?.(e.target.value);
  };

  const handleWelcomeMessageChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setWelcomeMessage(e.target.value);
    onWelcomeMessageChange?.(e.target.value);
  };

  return (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Type de Voix
        </label>
        <select 
          className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={voiceType}
          onChange={handleVoiceTypeChange}
        >
          <option>Femme - Professionnelle (25-35 ans)</option>
          <option>Homme - Professionnel (30-40 ans)</option>
          <option>Femme - Dynamique (20-30 ans)</option>
          <option>Homme - Posé (40-50 ans)</option>
        </select>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Vitesse de Parole
        </label>
        <input 
          type="range" 
          min="0.5" 
          max="2" 
          step="0.1" 
          defaultValue="1"
          className="w-full"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Message d'Accueil
        </label>
        <textarea 
          rows={4}
          className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={welcomeMessage}
          onChange={handleWelcomeMessageChange}
        />
      </div>

      <Button className="w-full">
        Écouter un Exemple
      </Button>
    </div>
  );
}