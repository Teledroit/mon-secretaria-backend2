import { Phone, Calendar, MessageCircle } from 'lucide-react';
import Button from '../ui/Button';
import { Link } from 'react-router-dom';

export default function Hero() {
  return (
    <div className="hero-gradient">
      <div className="container mx-auto px-4 py-24">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <div className="flex-1 text-center lg:text-left">
            <h1 className="text-5xl lg:text-7xl font-bold mb-6">
              <span className="gradient-text">Standardiste IA</span>
              <br />
              <span className="text-gray-900">Nouvelle Génération</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl">
              Un assistant téléphonique intelligent qui révolutionne la gestion de vos appels. 
              Disponible 24/7, il s'adapte parfaitement aux besoins de votre cabinet d'avocats.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Link to="/register">
                <Button size="lg" className="w-full sm:w-auto bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                  Essai Gratuit 14 Jours
                </Button>
              </Link>
              <Link to="/demo">
                <Button variant="outline" size="lg" className="w-full sm:w-auto">
                  Voir la Démonstration
                </Button>
              </Link>
            </div>
            <div className="mt-12 grid grid-cols-3 gap-8 max-w-2xl mx-auto lg:mx-0">
              {[
                { icon: Phone, label: '99.9% Disponibilité' },
                { icon: Calendar, label: 'Prise de RDV Intelligente' },
                { icon: MessageCircle, label: 'Support 24/7' }
              ].map((item, i) => (
                <div key={i} className="text-center">
                  <div className="mx-auto w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-2">
                    <item.icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <p className="text-sm font-medium text-gray-600">{item.label}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="flex-1 relative">
            <div className="w-full h-[500px] bg-gradient-to-br from-blue-500 to-purple-500 rounded-3xl blob-animation 
                          flex items-center justify-center p-8">
              <img
                src="https://images.unsplash.com/photo-1557426272-fc759fdf7a8d?auto=format&fit=crop&w=800&q=80"
                alt="Assistant IA"
                className="rounded-2xl shadow-2xl w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-xl shadow-lg max-w-xs">
              <div className="flex items-center gap-4 mb-3">
                <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
                <p className="font-medium">Assistant en ligne</p>
              </div>
              <p className="text-sm text-gray-600">
                "Bonjour, je suis votre assistant virtuel. Comment puis-je vous aider aujourd'hui ?"
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}