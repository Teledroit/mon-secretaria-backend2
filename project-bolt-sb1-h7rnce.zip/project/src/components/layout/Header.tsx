import { Link } from 'react-router-dom';
import { Phone, Menu } from 'lucide-react';
import Button from '../ui/Button';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="border-b bg-white sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <Phone className="w-8 h-8 text-blue-600" />
            <span className="text-xl font-semibold">MonSecretarIA</span>
          </Link>
          
          <nav className="hidden md:flex items-center space-x-6">
            <a href="#features" className="text-gray-600 hover:text-gray-900">Fonctionnalités</a>
            <a href="#pricing" className="text-gray-600 hover:text-gray-900">Tarifs</a>
            <a href="#contact" className="text-gray-600 hover:text-gray-900">Contact</a>
            <Link to="/login">
              <Button variant="outline">Connexion</Button>
            </Link>
            <Link to="/register">
              <Button>Essai Gratuit</Button>
            </Link>
          </nav>

          <button 
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <Menu className="w-6 h-6" />
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4">
            <nav className="flex flex-col space-y-4">
              <a href="#features" className="text-gray-600 hover:text-gray-900">Fonctionnalités</a>
              <a href="#pricing" className="text-gray-600 hover:text-gray-900">Tarifs</a>
              <a href="#contact" className="text-gray-600 hover:text-gray-900">Contact</a>
              <Link to="/login">
                <Button variant="outline" className="w-full">Connexion</Button>
              </Link>
              <Link to="/register">
                <Button className="w-full">Essai Gratuit</Button>
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}